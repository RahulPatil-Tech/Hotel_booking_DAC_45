package com.cdac.services;

import com.cdac.dto.ExplorerSignInRequest;
import com.cdac.dto.ExplorerSignupRequest;
import com.cdac.dto.UserResponse;

public interface ExplorerService {
    UserResponse registerNewExplorer(ExplorerSignupRequest dto);

    UserResponse authenticateExplorer(ExplorerSignInRequest dto);
}
