package com.cdac.dto;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HostServiceRequestDto {

    @NotBlank
    private String title;

    @NotBlank
    private String description;

    @Positive
    private int capacity;

    @Positive
    private double price;

    private String image;

    private boolean availability = true;
}
