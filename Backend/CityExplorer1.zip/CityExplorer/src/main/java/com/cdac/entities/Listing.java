package com.cdac.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name="listings",
        uniqueConstraints = @UniqueConstraint(columnNames = {
                "title","host_id"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true,exclude ="host")
public class Listing extends BaseEntity {

    @Column(nullable = false)
    private String title;

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    private boolean availability = true;

    @Positive
    private int capacity;

    @Positive
    private double price;

    @PositiveOrZero
    private double revenue = 0;

    private String image;

    @Enumerated(EnumType.STRING)
    private Category category;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "host_id", nullable = false)
    @JsonIgnore
    private Host host;
}


