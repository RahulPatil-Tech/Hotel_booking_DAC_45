package com.cdac.services;

import com.cdac.dto.BookingRequestDTO;
import com.cdac.dto.BookingResponseDTO;

import java.util.List;

public interface BookingService {
    BookingResponseDTO createBooking(BookingRequestDTO dto);
    List<BookingResponseDTO> getBookingsByExplorer(BookingRequestDTO dto);
}
