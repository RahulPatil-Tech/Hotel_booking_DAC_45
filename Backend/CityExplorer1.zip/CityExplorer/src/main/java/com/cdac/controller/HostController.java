package com.cdac.controller;

import com.cdac.dto.HostSignInRequest;
import com.cdac.dto.HostSignupRequest;
import com.cdac.services.HostService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/host")
@CrossOrigin(origins = "http://localhost:5173")
@AllArgsConstructor
public class HostController {

    @Autowired
    private HostService hostService;

    public HostController() {
        System.out.println("in ctor of " + getClass());
    }

    @PostMapping("/signup")
    @Operation(description = "Host sign up")
    public ResponseEntity<?> hostSignUp(
            @RequestBody @Valid HostSignupRequest dto ) {
        System.out.println("in host sign up "+dto);
        //invoke service method
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(hostService.registerNewHost(dto));
    }

    @PostMapping("/signin")
	@Operation(description = "Host sign in")
	public ResponseEntity<?> hostSignIn
	(@RequestBody @Valid HostSignInRequest dto)
	{
		System.out.println("in user sign in "+dto);
		//invoke service layer method n return resp packet
		return ResponseEntity.ok(hostService.authenticateHost(dto));
	}



}
