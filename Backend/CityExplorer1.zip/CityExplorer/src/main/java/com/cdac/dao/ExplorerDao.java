package com.cdac.dao;

import com.cdac.entities.Explorer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ExplorerDao extends JpaRepository<Explorer, Long> {
    boolean existsByEmail(String email);

    Optional<Explorer> findByEmailAndPassword(String email, String password);
}

