package com.cdac.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HostServiceResponseDto {
    private Long id;
    private String title;
    private String description;
    private int capacity;
    private double price;
    private boolean availability;
    private String image;
    private double revenue;
}
