package com.cdac.dao;

import com.cdac.entities.Listing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ListingDao extends JpaRepository<Listing, Long> {

}
