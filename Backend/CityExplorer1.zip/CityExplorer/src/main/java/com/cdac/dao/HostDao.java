package com.cdac.dao;

import com.cdac.entities.Host;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface HostDao extends JpaRepository<Host, Long> {
    boolean existsByEmail(String email);

    Optional<Host> findByEmailAndPassword(String email, String password);
}
