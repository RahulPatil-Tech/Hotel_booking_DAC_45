package com.cdac.services;

import com.cdac.dto.*;
import com.cdac.entities.Explorer;
import com.cdac.entities.Host;

import java.util.List;


public interface AdminService {
    UserResponse registerNewAdmin(AdminSignupRequest dto);

    UserResponse authenticateAdmin(AdminSignInRequest dto);

    List<Host> getAllHosts();

    List<ExplorerDTO> getAllExplorers();


    ApiResponse deleteHost(Long id);

    ApiResponse deleteExplorer(Long id);

    ApiResponse updateHost(Long id, HostSignInRequest dto);

    ApiResponse updateExplorer(Long id, ExplorerSignInRequest dto);
}