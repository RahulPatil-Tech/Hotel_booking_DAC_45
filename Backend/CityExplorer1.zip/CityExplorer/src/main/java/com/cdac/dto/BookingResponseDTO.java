package com.cdac.dto;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponseDTO {
    private Long id;
    private String title;
    private int noOfGuests;
    private double total;
    private Long explorerId;
    private Long hostId;
}