package com.cdac.services;

import com.cdac.custom_exceptions.ApiException;
import com.cdac.custom_exceptions.ResourceNotFoundException;
import com.cdac.dao.AdminDao;
import com.cdac.dao.ExplorerDao;
import com.cdac.dao.HostDao;
import com.cdac.dto.*;
import com.cdac.entities.*;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@AllArgsConstructor
public class AdminServiceImpl implements AdminService{
    private final AdminDao adminDao;
    private final HostDao hostDao;
    private final ExplorerDao explorerDao;
    private final ModelMapper modelMapper;
    @Override
    public UserResponse registerNewAdmin(AdminSignupRequest dto) {
        if(adminDao.existsByEmail(dto.getEmail()))
            throw new ApiException("Dup email detected !!!!!!");

        Admin entity=modelMapper.map(dto, Admin.class);

        entity.setRole(Role.ADMIN);

        return modelMapper.map(adminDao.save(entity),
                UserResponse.class);
    }

    @Override
    public UserResponse authenticateAdmin(AdminSignInRequest dto) {
        Admin entity = adminDao.findByEmailAndPassword(dto.getEmail(), dto.getPassword())
                .orElseThrow(() -> new ApiException("Invalid email or password!"));
        return modelMapper.map(entity,
                UserResponse.class);
    }

    @Override
    public List<Host> getAllHosts() {

        return hostDao.findAll()
                .stream()
                .map(host -> modelMapper.map(host, Host.class))
                .toList();
    }

    @Override
    public List<ExplorerDTO> getAllExplorers() {

        List<Explorer> explorers = explorerDao.findAll();

        return explorers.stream()
                .map(explorer -> new ExplorerDTO(explorer.getId(), explorer.getEmail(), explorer.getPassword()))
                .toList();
    }

    @Override
    public ApiResponse deleteHost(Long id) {
        if (hostDao.existsById(id)) {
            hostDao.deleteById(id);
            return new ApiResponse("Host deleted");
        }
        return new ApiResponse("host deletion failed!");
    }

    @Override
    public ApiResponse deleteExplorer(Long id) {
        if (explorerDao.existsById(id)) {
            explorerDao.deleteById(id);
            return new ApiResponse("Explorer deleted");
        }
        return new ApiResponse("explorer deletion failed!");
    }

    @Override
    public ApiResponse updateHost(Long id, HostSignInRequest dto) {
        Host host = hostDao.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Host not found with ID: " + id));

        host.setEmail(dto.getEmail());
        host.setPassword(dto.getPassword());

        hostDao.save(host);

        return new ApiResponse("Host updated successfully for ID: " + id);
    }

    @Override
    public ApiResponse updateExplorer(Long id, ExplorerSignInRequest dto) {
        Explorer explorer = explorerDao.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Explorer not found with ID: " + id));

        explorer.setEmail(dto.getEmail());
        explorer.setPassword(dto.getPassword());

        explorerDao.save(explorer);

        return new ApiResponse("Explorer updated successfully for ID: " + id);
    }


}
