package com.cdac.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminSignInRequest {
    private String email;
    private String password;
}
