package com.cdac.services;

import com.cdac.custom_exceptions.ApiException;
import com.cdac.dao.ExplorerDao;
import com.cdac.dto.ExplorerSignInRequest;
import com.cdac.dto.ExplorerSignupRequest;
import com.cdac.dto.UserResponse;
import com.cdac.entities.Explorer;
import com.cdac.entities.Host;
import com.cdac.entities.Role;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@AllArgsConstructor
public class ExplorerServiceImpl implements ExplorerService{
    private final ExplorerDao explorerDao;
    private final ModelMapper modelMapper;


    @Override
    public UserResponse registerNewExplorer(ExplorerSignupRequest dto) {
        if(explorerDao.existsByEmail(dto.getEmail()))
            throw new ApiException("Dup email detected !!!!!!");

        Explorer entity=modelMapper.map(dto, Explorer.class);

        entity.setRole(Role.EXPLORER);

        return modelMapper.map(explorerDao.save(entity),
                UserResponse.class);
    }

    @Override
    public UserResponse authenticateExplorer(ExplorerSignInRequest dto) {
        Explorer entity = explorerDao.findByEmailAndPassword(dto.getEmail(), dto.getPassword())
                .orElseThrow(() -> new ApiException("Invalid email or password!"));
        return modelMapper.map(entity,
                UserResponse.class);
    }
}
