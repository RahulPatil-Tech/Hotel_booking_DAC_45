package com.cdac.controller;

import com.cdac.dto.HostSignInRequest;
import com.cdac.dto.ListingDTO;
import com.cdac.entities.Category;
import com.cdac.services.ListingService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import jakarta.validation.Valid;
import lombok.AllArgsConstructor;



@RestController
@RequestMapping("/listing")
@CrossOrigin(origins = "http://localhost:5173")
@AllArgsConstructor
public class ListingController {

    private final ListingService listingService;

    @PostMapping("/view")
    public ResponseEntity<?> viewListings(@RequestBody HostSignInRequest dto) {
        return ResponseEntity.ok
                (listingService.getAllListing(dto));
    }

    @GetMapping("/categories")
    public  ResponseEntity<?> browseCategories() {
        return ResponseEntity.ok
                (Category.values());
    }

    @GetMapping("/categories/{category}")
    public ResponseEntity<?> getByCategory(@PathVariable Category category) {
        return ResponseEntity.ok(listingService.getListingsByCategory(category));
    }

    @GetMapping("/details/{id}")
    public ResponseEntity<?> getListingDetails(@PathVariable Long id) {
        return ResponseEntity.ok(listingService.getListingById(id));
    }

    @PutMapping("/booking/{id}/{qty}")
    public ResponseEntity<?> purchaseProducts(@PathVariable Long id,
                                              @PathVariable int qty) {
        return ResponseEntity.ok
                (listingService.booking(id,qty));
    }

    @PostMapping("/add")
    public  ResponseEntity<?> addListing(
            @RequestBody  @Valid ListingDTO listing) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(listingService.addListing(listing));
    }

    @DeleteMapping("/delete/{id}")
    //@PreAuthorize("hasRole('HOST')")
    public ResponseEntity<?> deleteListings(@PathVariable Long id, HostSignInRequest dto) {
        return ResponseEntity.ok
                (listingService.deleteProductDetails(id, dto));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateListing(@PathVariable Long id,
                                           @RequestBody @Valid ListingDTO listing) {
        return ResponseEntity.ok(listingService.updateListing(id, listing));
    }


}
