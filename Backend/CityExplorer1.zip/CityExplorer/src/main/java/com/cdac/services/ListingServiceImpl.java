package com.cdac.services;

import com.cdac.custom_exceptions.ApiException;
import com.cdac.custom_exceptions.ResourceNotFoundException;
import com.cdac.dao.HostDao;
import com.cdac.dto.ApiResponse;
import com.cdac.dto.HostSignInRequest;
import com.cdac.dto.ListingDTO;
import com.cdac.dto.ListingResponse;
import com.cdac.entities.Category;
import com.cdac.entities.Host;
import com.cdac.entities.Listing;

import java.util.List;
import java.util.stream.Collectors;

import com.cdac.repository.ListingRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class ListingServiceImpl implements ListingService{
    @Autowired
    private ListingRepository listingRepository;

    @Autowired
    private HostDao hostDao;

    @Autowired
    private ModelMapper mapper;

    @Override
    public List<Listing> getAllListing(HostSignInRequest dto) {
        Host host = hostDao.findByEmailAndPassword(dto.getEmail(), dto.getPassword())
                .orElseThrow(() -> new ApiException("Host not found with email: " + dto.getEmail()));

        return listingRepository.findAllByHostId(host.getId())
                .stream()
                .map(listing -> mapper.map(listing, Listing.class))
                .toList();
    }

    @Override
    public ApiResponse addListing(ListingDTO dto) {

        Host host = hostDao.findByEmailAndPassword(dto.getEmail(), dto.getPassword())
                .orElseThrow(() -> new ApiException("Host not found with email: " + dto.getEmail()));
        Listing listing = mapper.map(dto, Listing.class);
        listing.setHost(host);

        listingRepository.save(listing);
        return new ApiResponse("Added new product with ID " + listing.getId());
    }

    @Override
    public ApiResponse booking(Long id, int qty) {
        Listing listing = listingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid listing id !!!!"));
        listing.setCapacity(listing.getCapacity() - qty);
        return new ApiResponse("Booking confirmed!");
    }

    @Override
    public ApiResponse deleteProductDetails(Long id, HostSignInRequest dto) {
        /*Host host = hostDao.findByEmailAndPassword(dto.getEmail(), dto.getPassword())
                .orElseThrow(() -> new ApiException("Host not found with email: " + dto.getEmail()));*/

        if (listingRepository.existsById(id)) {
            listingRepository.deleteById(id);
            return new ApiResponse("deleted listing");
        }
        return new ApiResponse("listing deletion failed!");
    }

    @Override
    public ApiResponse updateListing(Long id, ListingDTO dto) {
        Listing listing = listingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Listing not found with ID: " + id));

        listing.setTitle(dto.getTitle());
        listing.setDescription(dto.getDescription());
        listing.setAvailability(dto.isAvailability());
        listing.setCapacity(dto.getCapacity());
        listing.setPrice(dto.getPrice());
        listing.setImage(dto.getImage());
        listing.setCategory(dto.getCategory());

        listingRepository.save(listing);

        return new ApiResponse("Listing updated successfully for ID: " + id);
    }

    @Override
    public List<ListingResponse> getListingsByCategory(Category category) {
        List<Listing> listings = listingRepository.findByCategory(category);
        return  listings.stream()
                .map(listing -> mapper.map(listing, ListingResponse.class))
                .collect(Collectors.toList());
    }

    @Override
    public ListingResponse getListingById(Long id) {
        Listing listing = listingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Listing not found"));
        return mapper.map(listing, ListingResponse.class);
    }

}
