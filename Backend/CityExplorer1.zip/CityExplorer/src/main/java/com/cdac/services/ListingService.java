package com.cdac.services;

import com.cdac.dto.ApiResponse;
import com.cdac.dto.HostSignInRequest;
import com.cdac.dto.ListingDTO;
import com.cdac.dto.ListingResponse;
import com.cdac.entities.Category;
import com.cdac.entities.Listing;
import com.cdac.repository.ListingRepository;

import java.util.List;

public interface ListingService {
    List<Listing> getAllListing(HostSignInRequest dto);

    ApiResponse addListing(ListingDTO listing);

    ApiResponse booking(Long id, int qty);

    ApiResponse deleteProductDetails(Long id, HostSignInRequest dto);

    ApiResponse updateListing(Long id, ListingDTO listing);

    List<ListingResponse> getListingsByCategory(Category category);

    ListingResponse getListingById(Long id);
}
