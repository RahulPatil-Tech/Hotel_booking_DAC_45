package com.cdac.services;

import com.cdac.custom_exceptions.ApiException;
import com.cdac.dao.ExplorerDao;
import com.cdac.dto.BookingRequestDTO;
import com.cdac.dto.BookingResponseDTO;
import com.cdac.entities.Booking;
import com.cdac.entities.Explorer;
import com.cdac.entities.Listing;
import com.cdac.repository.BookingRepository;
import com.cdac.repository.ListingRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final ExplorerDao explorerDao;
    private final ModelMapper mapper;
    private final ListingRepository listingRepository;

    @Override
    public BookingResponseDTO createBooking(BookingRequestDTO dto) {
        Explorer explorer = explorerDao.findByEmailAndPassword(dto.getEmail(), dto.getPassword())
                .orElseThrow(() -> new ApiException("Invalid email or password"));

        Listing listing = listingRepository.findById(dto.getListingId())
                .orElseThrow(() -> new ApiException("Listing not found"));

        Booking booking = new Booking();

        booking.setTitle(listing.getTitle());
        booking.setNoOfGuests(dto.getNoOfGuests());
        booking.setTotal(listing.getPrice() * dto.getNoOfGuests());
        booking.setExplorer(explorer);
        booking.setListing(listing);
        booking.setHost(listing.getHost());

        listing.setRevenue(listing.getRevenue() + booking.getTotal());
        listingRepository.save(listing);

        return mapper.map(bookingRepository.save(booking), BookingResponseDTO.class);
    }

    @Override
    public List<BookingResponseDTO> getBookingsByExplorer(BookingRequestDTO dto) {
        Explorer explorer = explorerDao.findByEmailAndPassword(dto.getEmail(), dto.getPassword())
                .orElseThrow(() -> new ApiException("Invalid email or password"));

        return bookingRepository.findByExplorerId(explorer.getId()).stream()
                .map(booking -> mapper.map(booking, BookingResponseDTO.class))
                .collect(Collectors.toList());
    }
}
