package com.cdac.controller;

import com.cdac.dto.BookingRequestDTO;
import com.cdac.dto.BookingResponseDTO;
import com.cdac.services.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "http://localhost:5173")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @PostMapping("/create")
    public ResponseEntity<BookingResponseDTO> createBooking(@RequestBody BookingRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(bookingService.createBooking(dto));
    }

    @PostMapping("/book")
    public ResponseEntity<?> bookListing(@RequestBody BookingRequestDTO dto) {
        BookingResponseDTO bookingResponse = bookingService.createBooking(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(bookingResponse);
    }

    @PostMapping("/explorer/auth")
    public ResponseEntity<List<BookingResponseDTO>> getExplorerBookings(@RequestBody BookingRequestDTO dto) {
        return ResponseEntity.ok(bookingService.getBookingsByExplorer(dto));
    }
}
