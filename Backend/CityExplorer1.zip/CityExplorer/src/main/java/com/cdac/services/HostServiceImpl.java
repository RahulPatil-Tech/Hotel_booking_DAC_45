package com.cdac.services;

import com.cdac.custom_exceptions.ApiException;
import com.cdac.dao.HostDao;
import com.cdac.dto.HostSignInRequest;
import com.cdac.dto.HostSignupRequest;
import com.cdac.dto.UserResponse;
import com.cdac.entities.Host;
import com.cdac.entities.Role;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class HostServiceImpl implements HostService{
    private final HostDao hostDao;
    private final ModelMapper modelMapper;

    @Override
    public UserResponse registerNewHost(HostSignupRequest dto) {
        if(hostDao.existsByEmail(dto.getEmail()))
            throw new ApiException("Dup email detected !!!!!!");

        Host entity=modelMapper.map(dto, Host.class);

        entity.setRole(Role.HOST);

        return modelMapper.map(hostDao.save(entity),
                UserResponse.class);
    }

    @Override
    public UserResponse authenticateHost(HostSignInRequest dto) {
        Host entity = hostDao.findByEmailAndPassword(dto.getEmail(), dto.getPassword())
                .orElseThrow(() -> new ApiException("Invalid email or password!"));
        return modelMapper.map(entity,
                UserResponse.class);
    }
}
