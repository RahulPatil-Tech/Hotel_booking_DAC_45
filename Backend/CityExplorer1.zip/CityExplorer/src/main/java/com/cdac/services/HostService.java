package com.cdac.services;

import com.cdac.dto.HostSignInRequest;
import com.cdac.dto.HostSignupRequest;
import com.cdac.dto.UserResponse;
import org.springframework.http.ResponseEntity;

public interface HostService {
    UserResponse registerNewHost(HostSignupRequest dto);

    UserResponse authenticateHost(HostSignInRequest dto);
}
