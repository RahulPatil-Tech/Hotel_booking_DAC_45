package com.cdac.controller;

import com.cdac.dto.*;
import com.cdac.services.AdminService;
import com.cdac.services.HostService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:5173")
@AllArgsConstructor
public class AdminController {

    @Autowired
    private AdminService adminService;

    public AdminController() {
        System.out.println("in ctor of " + getClass());
    }

    @PostMapping("/signup")
    @Operation(description = "Admin sign up")
    public ResponseEntity<?> adminSignUp(
            @RequestBody @Valid AdminSignupRequest dto ) {
        System.out.println("in host sign up "+dto);
        //invoke service method
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(adminService.registerNewAdmin(dto));
    }

    @PostMapping("/signin")
    @Operation(description = "Admin sign in")
    public ResponseEntity<?> adminSignIn
            (@RequestBody @Valid AdminSignInRequest dto)
    {
        System.out.println("in user sign in "+dto);
        //invoke service layer method n return resp packet
        return ResponseEntity.ok(adminService.authenticateAdmin(dto));
    }


    @PostMapping("/view-hosts")
    public ResponseEntity<?> viewAllHosts() {
        return ResponseEntity.ok
                (adminService.getAllHosts());
    }

    @CrossOrigin(origins = "http://localhost:5173")
    @PostMapping("/view-explorers")
    public ResponseEntity<?> viewAllExplorers() {
        return ResponseEntity.ok
                (adminService.getAllExplorers());
    }

    @CrossOrigin(origins = "http://localhost:5173")
    @DeleteMapping("/delete-host/{id}")
    //@PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteHost(@PathVariable Long id) {
        return ResponseEntity.ok
                (adminService.deleteHost(id));
    }

    @CrossOrigin(origins = "http://localhost:5173")
    @DeleteMapping("/delete-explorer/{id}")
    //@PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteExplorer(@PathVariable Long id) {
        return ResponseEntity.ok
                (adminService.deleteExplorer(id));
    }

    @CrossOrigin(origins = "http://localhost:5173")
    @PutMapping("/update-host/{id}")
    public ResponseEntity<?> updateHost(@PathVariable Long id, @RequestBody @Valid HostSignInRequest dto) {
        return ResponseEntity.ok(adminService.updateHost(id, dto));
    }

    @CrossOrigin(origins = "http://localhost:5173")
    @PutMapping("/update-explorer/{id}")
    public ResponseEntity<?> updateExplorer(@PathVariable Long id, @RequestBody @Valid ExplorerSignInRequest dto) {
        return ResponseEntity.ok(adminService.updateExplorer(id, dto));
    }


}
