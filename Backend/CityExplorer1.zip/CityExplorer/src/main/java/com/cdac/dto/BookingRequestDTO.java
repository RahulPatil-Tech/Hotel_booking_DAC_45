package com.cdac.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequestDTO {
    private String email;
    private String password;
    private Long listingId;
    private int noOfGuests;

}

