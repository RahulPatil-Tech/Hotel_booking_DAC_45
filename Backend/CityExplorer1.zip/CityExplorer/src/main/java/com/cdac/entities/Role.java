package com.cdac.entities;

public enum Role {
    ADMIN,
    EXPLORER,
    HOST
}
