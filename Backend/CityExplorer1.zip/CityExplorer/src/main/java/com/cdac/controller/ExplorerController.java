package com.cdac.controller;


import com.cdac.dto.ExplorerSignInRequest;
import com.cdac.dto.ExplorerSignupRequest;
import com.cdac.services.ExplorerService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/explorer")
@CrossOrigin(origins = "http://localhost:5173")
@AllArgsConstructor
public class ExplorerController {

    @Autowired
    private ExplorerService explorerService;

    public ExplorerController() {
        System.out.println("in ctor of " + getClass());
    }

    @PostMapping("/signup")
    @Operation(description = "Explorer sign up")
    public ResponseEntity<?> explorerSignUp(
            @RequestBody @Valid ExplorerSignupRequest dto ) {
        System.out.println("in explorer sign up "+dto);
        //invoke service method
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(explorerService.registerNewExplorer(dto));
    }

    @PostMapping("/signin")
    @Operation(description = "Explorer sign in")
    public ResponseEntity<?> explorerSignIn
            (@RequestBody @Valid ExplorerSignInRequest dto)
    {
        System.out.println("in user sign in "+dto);
        return ResponseEntity.ok(explorerService.authenticateExplorer(dto));
    }



}
